<?php
echo md5_file( 'baner.tga' );
?>