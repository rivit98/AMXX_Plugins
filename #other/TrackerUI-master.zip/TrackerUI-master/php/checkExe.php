<?php
echo md5_file( 'Tracker.exe' );
?>