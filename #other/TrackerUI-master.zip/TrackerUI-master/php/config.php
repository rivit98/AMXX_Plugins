<?php
$mysql_host = '';
$port = '';
$username = '';
$password = '';
$database = '';
?>