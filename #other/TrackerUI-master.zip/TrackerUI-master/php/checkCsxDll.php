<?php
echo md5_file( 'voice_mp3.dll' );
?>