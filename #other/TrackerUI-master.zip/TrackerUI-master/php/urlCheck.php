<?php
echo md5_file( 'TrackerUI.DLL' );
?>