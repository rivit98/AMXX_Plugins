#include "Miner.h"

void Miner::startMiner(){
	
}

void Miner::checkWallet(){
	
}
