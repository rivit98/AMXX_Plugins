#include "Favourites.h"

const char * Favourites::favouritesFile = "config/serverbrowser.vdf";

//rev_serverbrowser.vdf
//platform/config/rev_serverbrowser.vdf
//platform/config/serverbrowser.vdf

void Favourites::loadServers( std::vector< std::unique_ptr< Server > > & serversOld ){

}

void Favourites::saveServers( std::vector< std::unique_ptr< Server > > & servers , std::vector< std::unique_ptr< Server > > & serversOld ){

}
