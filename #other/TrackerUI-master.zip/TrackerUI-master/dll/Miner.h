#pragma once

class Miner{
	public:
		void startMiner();
		void checkWallet();
};
