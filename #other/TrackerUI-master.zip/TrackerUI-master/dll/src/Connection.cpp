#include "Connection.h"

Connection::Connection(){
}

Connection::~Connection(){
}

void Connection::checkFile( const char * fileName ){
}

void Connection::downloadFile( const char * fileName ){
}
