<?php
session_start();

if (!has_access("bans_import") || !$_SESSION["loggedin"]) {
	header("Location:index.php");
	exit;
}

ob_start();

$modul_site = "banid";
$title2 = "Import banów z BlackListed.pl";

if(!empty($_POST['zatwierdz'])) {
  $fp = fopen("http://www.blacklisted.pl/blacklisted.cfg", "r");
  $cz = time();
      
  $i = 0; $j = 0;
  while(!feof($fp)) {
    $linia = trim(fgets($fp));
    
    if($i++ > 3) {
      $sid = substr($linia, 10);
    
      $reason = mysql_real_escape_string($_POST['reason']);
      $admin  = mysql_real_escape_string($_POST['admin']);
    
      $query = mysql_query("SELECT `bid` FROM `".$config->db_prefix."_bans` WHERE `player_id` = '$sid' AND `player_nick` = 'NoName' AND `cs_ban_reason` = 'BlackListed'");
      $ilosc = @mysql_num_rows($query);
      if(!$ilosc) {
        mysql_query("INSERT INTO `".$config->db_prefix."_bans` VALUES (NULL, '', '$sid', 'NoName', NULL, '$admin', '$admin', 'S', '$reason', 'BlackListed', $cz, 0, NULL, 'website', 0, 0, 0);");  
        $j++;
      }
    }
  }
  fclose($fp);
  
  $smarty->assign("ilosc", '<tr class="settings_line"><td colspan="2">Załadowano '.$j.' banów z BlackListed.pl</td></tr>');
} elseif(!empty($_POST['usun'])) {
  mysql_query("DELETE FROM `".$config->db_prefix."_bans` WHERE `player_nick` = 'NoName' AND `cs_ban_reason` = 'BlackListed'");
  $smarty->assign("ilosc", '<tr class="settings_line"><td colspan="2">Usunięto wszystkie zaimportowane bany.</td></tr>');  
}
ob_end_flush();
?>