<?php
session_start();

require_once("include/config.inc.php");
require_once("include/functions.inc.php");
require_once("include/menu.inc.php");

$title = "_TITLEREPORT";
$smarty = new dynamicPage;

if(isset($_POST["actionreport"])) {
	$nick = sql_safe($_POST["nick"]);
	$ip = sql_safe($_POST["ip"]);
	$sid = sql_safe($_POST["sid"]);
	$date = sql_safe($_POST["date"]);
	$server = sql_safe($_POST["server"]);
	$demo = sql_safe($_POST["demo"]);
	$screen = sql_safe($_POST["screen"]);
	$note = sql_safe($_POST["note"]);
	
	if(!$nick || !$ip || !$sid || !$date || !$server || !$note) {
		$failed="_REPORTFAILED";
	}
	else if(!$demo && !$screen) {
		$failed="_REPORTFAILEDMEDIA";
	}
	else if(strlen($note) > 240) {
		$failed="_REPORTLONGNOTE";
	}
	
	if($demo) {
		if(!preg_match('#^http[s]?:\/\/#i', $demo)) {
			$demo = "http://" . $demo;
		}
		if(!preg_match('#^http[s]?\\:\\/\\/[a-z0-9\-]+\.([a-z0-9\-]+\.)?[a-z]+#i', $demo)) {
			$failed="_REPORTBADADRESD";
		}
	}
	if($screen) {
		if(!preg_match('#^http[s]?:\/\/#i', $screen)) {
			$screen = "http://" . $screen;
		}
		if(!preg_match('#^http[s]?\\:\\/\\/[a-z0-9\-]+\.([a-z0-9\-]+\.)?[a-z]+#i', $screen)) {
			$failed="_REPORTBADADRESS";
		}
	}
	
	if(!$failed) {
		$unixtime = 0;
		$time = time();
		$date2 = explode('-',$date);
		
		if(checkdate($date2[1],$date2[0],$date2[2])) {
			$unixtime = mktime(0,0,0,$date2[1],$date2[0],$date2[2]);
		}
		
		$des = $note;
		$des = $des."\n";
		
		if($demo) {
			$des = $des."\nDemo: ";
			$des = $des.$demo;
		}
		if($screen) {
			$des = $des."\nSS: ";
			$des = $des.$screen;
		}
		
		$query = mysql_query("INSERT INTO `".$config->db_prefix."_reportcenter` (`report_type`,`nickname`,`servers`,`description`,`timestamp`,`more1`,`more2`,`more3`) VALUES ('1','$nick','$server','$des','$time','$ip','$sid','$unixtime')");
		$msg="_REPORTSEND";
	}
}
/*
$servers=sql_get_servers();

function sql_get_servers() {
	global $config;
	$query = mysql_query("SELECT `id`,`hostname` FROM `".$config->db_prefix."_serverinfo` GROUP BY `id` ORDER BY `hostname` ASC") or die (mysql_error());
	
	while($result = mysql_fetch_object($query)) {
		$servers[$result->id]=htmlsafe_recursive($result->hostname);
	}

	return $servers;
}*/

$servers=sql_get_server();
$svalues=array();
$soutput=array();

if(is_array($servers)) {
	foreach($servers as $k => $v) {
		$svalues[]=$v["sid"];
		$soutput[]=$v["hostname"];
	}
}

$smarty->assign("meta","");
$smarty->assign("title",$title);
$smarty->assign("banner",$config->banner);
$smarty->assign("banner_url",$config->banner_url);
$smarty->assign("version_amxx",$config->v_amxx);
$smarty->assign("dir",$config->document_root);
$smarty->assign("this",$_SERVER['PHP_SELF']);
$smarty->assign("menu",$menu);
$smarty->assign("failed",$failed);
$smarty->assign("msg",$msg);
$smarty->assign("svalues",$svalues);
$smarty->assign("soutput",$soutput);
if(file_exists("templates/".$config->design."/main_header.tpl")) {
	$smarty->assign("design",$config->design);
}
$smarty->display('main_header.tpl');
$smarty->display('sus_player.tpl');
$smarty->display('main_footer.tpl');
?>