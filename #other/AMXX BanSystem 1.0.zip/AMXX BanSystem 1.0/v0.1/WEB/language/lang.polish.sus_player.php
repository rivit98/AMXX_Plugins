﻿<?php
define("_TITLEREPORT", "Podejrzany typ");
define("_REPORTFAILED", "Uzupełnij wszystkie pola!");
define("_REPORTFAILEDMEDIA", "Musisz wpisać link do dema lub screena!");
define("_DEMO", "Link do dema");
define("_DEMODES", "Demo jest konieczne w przypadku zgłaszania czita");
define("_SCREEN", "Link do screena");
define("_SCREENDES", "Screen jest konieczny w przypadku zgłaszania obrazy");
define("_REPORTBADADRESD", "Podano zły adres do dema");
define("_REPORTBADADRESS", "Podano zły adres do screena");
define("_REPORTLONGNOTE", "Komentarz do zgłoszenia jest zbyt długi");
define("_REPORTNOTE", "Krótki komentarz do zgłoszenia");
define("_REPORTSEND", "Zgłoszenie zostało wysłane");
define("_REPORT_SEND", "Wyślij");
?>