define("_BANID_N", "Bans Import");
define("_BANID_D", "Import bans from BlackListed.pl");
define("_BANID_I", "Import banlist from BlackListed.pl to database");

define("_BANID_R", "Type ban reason:");
define("_BANID_A", "Admin:");
?>