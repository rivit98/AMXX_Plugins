<?php
define("_BANID_N", "Import banów");
define("_BANID_D", "Import banów z BlackListed.pl");
define("_BANID_I", "Zaimportuj listę banów z BlackListed.pl do bazy");

define("_BANID_R", "Podaj powód banów:");
define("_BANID_A", "Admin:");
define("_BANID_DEL", "Usuń wszystkie zaimportowane bany");
?>