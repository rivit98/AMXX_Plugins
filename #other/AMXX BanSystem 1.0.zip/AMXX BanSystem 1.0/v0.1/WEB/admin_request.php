<?php
@session_start();

require_once("include/config.inc.php");
require_once("include/access.inc.php");
require_once("include/sql.inc.php");
require_once("include/menu.inc.php");
require_once("include/functions.inc.php");

$msg = "";

if(isset($_POST['action']))
{
    $nickname = sql_safe($_POST['nickname']);
    $auth_type = $_POST['auth_type'];
    $serverID = $_POST['server'];
    $game_name = sql_safe($_POST['game_name']);
    $description = sql_safe($_POST['description']);
    $timestamp = time();
    if(isset($_POST['password']) && $_POST['password'] != "")
        $password = md5($_POST['password']);
    else
        $password = "NULL";
    
    if(!$nickname || !isset($_POST['auth_type']) || !$game_name || !$description || !isset($_POST['server']) || ($auth_type == "0" && $password == "NULL"))
    {
        $msg[] = "Wypełnij WSZYSTKIE POTRZEBNE pola";
    }
    
    if(strlen($description) < 15)
    {
        $msg[] = "Tak malo? Opisz sie bardziej :)";
    }
    
    
    
    if(!$msg)
    {        
        mysql_query("INSERT INTO `" . $config->db_prefix . "_reportcenter` VALUES ( NULL, 0, '$nickname', '$serverID', '$description', '$timestamp', '$auth_type','$game_name', '$password' )");
        $msg[] = "Podanie wyslane!";
    }
}

//server holen
$servers=sql_get_server();
$svalues = array();
$soutput = array();

if(is_array($servers)) {
    foreach($servers as $k => $v) {
        $svalues[]=$v["sid"];
        $soutput[]=$v["hostname"];
    }
}

// Template generieren
$title = "_TITLEADMINREQUEST";
$smarty = new dynamicPage;

$smarty->assign("meta","");
$smarty->assign("title",$title);
$smarty->assign("banner",$config->banner);
$smarty->assign("banner_url",$config->banner_url);
$smarty->assign("version_web",$config->v_web);
$smarty->assign("dir",$config->document_root);
$smarty->assign("this",$_SERVER['PHP_SELF']);
$smarty->assign("menu",$menu);
$smarty->assign("msg",$msg);
$smarty->assign("svalues",$svalues);
$smarty->assign("soutput",$soutput);

if(file_exists("templates/".$config->design."/main_header.tpl")) {
	$smarty->assign("design",$config->design);
}

$smarty->display('main_header.tpl');
$smarty->display('admin_request.tpl');
$smarty->display('main_footer.tpl');
?>